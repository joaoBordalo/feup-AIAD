package perceptions;

import java.util.Vector;

public abstract class Perception {
	
	public Perception(){
		
	}
	
}
