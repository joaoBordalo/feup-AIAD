package actions;

public abstract class Action {
	
	public Action() {
		// TODO Auto-generated constructor stub
	}

}
