package actions;

public class DontFortifyAction extends Action{

}
