package actions;

public class DontAttackAction extends Action {
	
	public DontAttackAction() {
		// TODO Auto-generated constructor stub
	}

}
