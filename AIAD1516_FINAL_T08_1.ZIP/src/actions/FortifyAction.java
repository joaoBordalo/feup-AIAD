package actions;

public class FortifyAction {

}
